#include "provided.h"
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class MapLoaderImpl
{
public:
	MapLoaderImpl();
	~MapLoaderImpl();
	bool load(string mapFile);
	size_t getNumSegments() const;
	bool getSegment(size_t segNum, StreetSegment& seg) const;
private:
    vector<StreetSegment*> m_segments;
    vector<Attraction*> m_attractions;
    static GeoSegment getGeoSegment(string line);
    static Attraction getAttraction(string line);
};

MapLoaderImpl::MapLoaderImpl()
{
    m_segments = vector<StreetSegment*>();
}

MapLoaderImpl::~MapLoaderImpl()
{
    while (m_segments.size() > 0) {
        delete m_segments[0];
        m_segments.erase(m_segments.begin());
    }
    while (m_attractions.size() > 0) {
        delete m_attractions[0];
        m_attractions.erase(m_attractions.begin());
    }
}


GeoSegment MapLoaderImpl::getGeoSegment(string line) {
    string coord_pairs[2];
    string coords[4];
    size_t start = line.find(", ");
    line.replace(start, 2, ",");
    size_t middle = line.find(" ");
    coord_pairs[0] = line.substr(0, middle);
    coord_pairs[1] = line.substr(middle + 1, (line.length() - middle - 1));
    for (int i = 0;i<2;i++) {
        middle = coord_pairs[i].find(",");
        coords[i*2] = coord_pairs[i].substr(0, middle);
        coords[i*2 + 1] = coord_pairs[i].substr(middle + 1, (coord_pairs[i].length() - middle - 1));
    }
    return GeoSegment(GeoCoord(coords[0], coords[1]), GeoCoord(coords[2], coords[3]));
}

Attraction MapLoaderImpl::getAttraction(string line) {
    Attraction attraction;
    size_t divider = line.find("|");
    attraction.name = line.substr(0, divider);
    string coord_pair = line.substr(divider + 1, (line.length() - divider - 1));
    size_t middle = coord_pair.find(", ");
    string xLoc, yLoc;
    xLoc = coord_pair.substr(0, middle);
    yLoc = coord_pair.substr(middle + 2, (coord_pair.length() - middle - 2));
    attraction.geocoordinates = GeoCoord(xLoc, yLoc);
    return attraction;
}

bool MapLoaderImpl::load(string mapFile)
{
    ifstream infile(mapFile);
    if (!infile) {
        cerr << "Error: cannot open " << mapFile << endl;
        return false;
    }
    string line;
    //loop foreeeeever
    while (true) {
        if (!getline(infile, line)) break;
        StreetSegment* ssegment = new StreetSegment;
        ssegment->streetName = line;
        if (!getline(infile, line)) return false;
        ssegment->segment = MapLoaderImpl::getGeoSegment(line);
        if (!getline(infile, line)) return false;
        int num_attractions = stoi(line);
        Attraction* attraction = nullptr;
        for (int i = 0;i<num_attractions;i++) {
            if (!getline(infile, line)) return false;
            attraction = new Attraction;
            size_t divider = line.find("|");
            attraction->name = line.substr(0, divider);
            //cout << attraction->name << endl;
            string coord_pair = line.substr(divider + 1, (line.length() - divider - 1));
            size_t middle = coord_pair.find(", ");
            string xLoc, yLoc;
            xLoc = coord_pair.substr(0, middle);
            yLoc = coord_pair.substr(middle + 2, (coord_pair.length() - middle - 2));
            attraction->geocoordinates = GeoCoord(xLoc, yLoc);
            this->m_attractions.push_back(attraction);
            ssegment->attractions.push_back(*attraction);
        }
        this->m_segments.push_back(ssegment);
    }
    return this->m_segments.size() > 0;
}

size_t MapLoaderImpl::getNumSegments() const
{
    return m_segments.size();
}

bool MapLoaderImpl::getSegment(size_t segNum, StreetSegment &seg) const
{
    if (segNum < 0 || segNum >= m_segments.size()) return false;
    seg = *m_segments[segNum];
    return true;
}

//******************** MapLoader functions ************************************

// These functions simply delegate to MapLoaderImpl's functions.
// You probably don't want to change any of this code.

MapLoader::MapLoader()
{
	m_impl = new MapLoaderImpl;
}

MapLoader::~MapLoader()
{
	delete m_impl;
}

bool MapLoader::load(string mapFile)
{
	return m_impl->load(mapFile);
}

size_t MapLoader::getNumSegments() const
{
	return m_impl->getNumSegments();
}

bool MapLoader::getSegment(size_t segNum, StreetSegment& seg) const
{
   return m_impl->getSegment(segNum, seg);
}





