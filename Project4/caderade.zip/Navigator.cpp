
#include "provided.h"
#include "support.h"
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


struct Node {
    GeoCoord coord;
    Node* parent;
    double g;
    double h;
    double f() const { return g + h; }
};

class NavigatorImpl
{
public:
    NavigatorImpl();
    ~NavigatorImpl();
    bool loadMapData(string mapFile);
    NavResult navigate(string start, string end, vector<NavSegment>& directions);
    struct MapNode {
        MapNode(StreetSegment* segment, MapNode* parent, double g, double h) {
            this->segment = segment;
            this->parent = parent;
            this->g = g;
            this->h = h;
        }
        MapNode(StreetSegment* segment) {
            this->segment = segment;
            this->parent = nullptr;
            this->g = -1;
            this->h = -1;
        }
        ~MapNode() {
            //cerr << "DELETING MAPNODE HERE" << endl;
        }
        StreetSegment* segment;
        MapNode* parent;
        double g;
        double h;
        double f() const {return g + h;}
        bool operator<(MapNode rhs) {
            return (this->f() < rhs.f());
        }
        void print() {
            cout << this->segment->streetName << " " << this->segment->segment.start.latitudeText << ", " << segment->segment.start.longitudeText << endl;
        }
    };

    
private:
    MapLoader m_mloader;
    SegmentMapper m_smapper;
    AttractionMapper m_amapper;
    
    
    vector<MapNode*> m_dynamicNodes;
    
    bool getSegment(string start, StreetSegment& segment) const;
    NavigatorImpl::MapNode* popNodeWithLeastCost(vector<MapNode*>& open_list) const;
    vector<MapNode*> generateSuccessors(MapNode* q);
    double getSegmentDistance(const StreetSegment& segment) const;
    bool hasNodeWithLowerCost(const vector<MapNode*>& list, MapNode* node) const;
};


NavigatorImpl::NavigatorImpl()
{
}

NavigatorImpl::~NavigatorImpl()
{
    for (int i = 0;i<m_dynamicNodes.size();i++) {
        delete m_dynamicNodes[i];
    }
}



bool NavigatorImpl::loadMapData(string mapFile)
{
    if (!this->m_mloader.load(mapFile)) return false;
    this->m_smapper.init(m_mloader);
    this->m_amapper.init(m_mloader);
    return true;
}

/*
 Returns the first StreetSegment associated with the attraction name given
*/
bool NavigatorImpl::getSegment(string start, StreetSegment& segment) const {
    GeoCoord coord;
    if (!this->m_amapper.getGeoCoord(start, coord)) return false;
    vector<StreetSegment> segs = this->m_smapper.getSegments(coord);
    if (segs.empty()) return false;
    segment = segs[0];
    return true;
}

/*
 Finds the MapNode with the lowest total cost (f()) and erases it from the passed in vector,
 returning the erased node.
*/
NavigatorImpl::MapNode* NavigatorImpl::popNodeWithLeastCost(vector<MapNode*>& open_list) const {
    double minCost = open_list[0]->f();
    double minIndex = 0;
    for (int i = 0;i<open_list.size();i++) {
        if (open_list[i]->f() < minCost) {
            minCost = open_list[i]->f();
            minIndex = i;
        }
    }
    MapNode* res = open_list[minIndex];
    open_list.erase(open_list.begin() + minIndex);
    return res;
}

/*
 Finds all the StreetSegments whose start nodes are the same as the end node of the
 StreetSegment of q passed in
*/
vector<NavigatorImpl::MapNode*> NavigatorImpl::generateSuccessors(MapNode* q) {
    vector<NavigatorImpl::MapNode*> res;
    vector<StreetSegment> segments = this->m_smapper.getSegments(q->segment->segment.end);
    for (int i = 0;i<segments.size();i++) {
        for (int k = 0;k<q->segment->attractions.size();k++) {
            cout << "ATTRACTION: " << segments[i].attractions[k].name << endl;
        }
    }
    for (int i = 0;i<segments.size();i++) {
        //if the start of the new segment is equal to the end of the old one
        //AND it's not the same as q, then add it to the result list
        //if (segments[i].segment.start == q.segment->segment.end && !(segments[i] == *(q.segment))) {
        
        if (!(segments[i] == *(q->segment))) {
        cout << "CURRENT SEGMENT NAME: " << q->segment->streetName << " " << q->segment->segment.start.latitudeText << " " << q->segment->segment.start.longitudeText << endl;
            for (int k = 0;k<q->segment->attractions.size();k++) {
                cout << "ATTRACTION: " << q->segment->attractions[k].name << endl;
            }
        cout << "SUCCESSOR SEGMENT NAME: " << segments[i].streetName << " " << segments[i].segment.start.latitudeText << " " << segments[i].segment.start.longitudeText << endl;
            for (int k = 0;k<q->segment->attractions.size();k++) {
                cout << "ATTRACTION: " << segments[i].attractions[k].name << endl;
            }
            MapNode* node = new MapNode(&segments[i]);
            node->parent = q;
            this->m_dynamicNodes.push_back(node);
            res.push_back(node);
        }
        
    }
    return res;
}

/*
 Returns the distance of a StreetSegment object in kilometers
*/

double NavigatorImpl::getSegmentDistance(const StreetSegment &segment) const {
    return distanceEarthKM(segment.segment.start, segment.segment.end);
}

/*
 Checks if there is a node in the list with a lower f() than the passed in
 node that also has the same position
*/

bool NavigatorImpl::hasNodeWithLowerCost(const vector<MapNode*>& list, MapNode* node) const {
    double cost = node->f();
    for (int i = 0;i<list.size();i++) {
        if (*(list[i]->segment) == *(node->segment) && list[i]->f() < cost) return true;
    }
    return false;
}


NavResult NavigatorImpl::navigate(string start, string end, vector<NavSegment> &directions)
{
    GeoCoord startCoord, endCoord;
    if (!m_amapper.getGeoCoord(start, startCoord)) return NAV_BAD_SOURCE;
    if (!m_amapper.getGeoCoord(end, endCoord)) return NAV_BAD_DESTINATION;
    vector<Node*> open_list;
    vector<Node*> closed_list;
    
    Node* startNode = new Node;
    startNode->parent = nullptr;
    startNode->coord = startCoord;
    startNode->g = 0;
    startNode->h = distanceEarthKM(startCoord, endCoord);
    
    open_list.push_back(startNode);
    
    while(!open_list.empty()) {
        //pop the node with the lowest f
        double minIndex = 0;
        for (int i = 0;i<open_list.size();i++) {
            if (open_list[i]->f() < open_list[minIndex]->f()) {
                minIndex = i;
            }
        }
        Node* q = open_list[minIndex];
        open_list.erase(open_list.begin() + minIndex);
        //generate successors
        vector<StreetSegment> cSegs = this->m_smapper.getSegments(q->coord);
        for (int i = 0;i<cSegs.size();i++) {
            cout << cSegs[i].streetName << endl;
            //check if this segment is the goal
            for (int j = 0;j<cSegs[i].attractions.size();j++) {
                if (cSegs[i].attractions[j].name == end) {
                    cerr << "FOUND THE END" << endl;
                    return NAV_SUCCESS;
                }
            }
        }
        
        for (int i = 0;i<cSegs.size();i++) {
            //create a successor from the start
            Node* sNext = new Node;
            sNext->coord = cSegs[i].segment.start;
            sNext->parent = q;
            sNext->g = q->g + distanceEarthKM(q->coord, sNext->coord);
            sNext->h = distanceEarthKM(sNext->coord, endCoord);
            
            //check the open and closed lists
            bool skipStart = false;
            if (sNext->coord == q->coord) skipStart = true;
            for (int j = 0;j<open_list.size();j++) {
                if (open_list[j]->coord == sNext->coord && open_list[j]->f() <= sNext->f()) {
                    skipStart = true;
                    break;
                }
            }
            if (!skipStart) {
                for (int j = 0;j<closed_list.size();j++) {
                    if (closed_list[j]->coord == sNext->coord && closed_list[j]->f() <= sNext->f()) {
                        skipStart = true;
                        break;
                    }
                }
            }
            if (!skipStart) open_list.push_back(sNext);
            
            //create a successor from the end
            Node* eNext = new Node;
            eNext->coord = cSegs[i].segment.end;
            eNext->parent = q;
            eNext->g = q->g + distanceEarthKM(q->coord, eNext->coord);
            eNext->h = distanceEarthKM(eNext->coord, endCoord);
            
            //check the open and closed lists
            bool skipEnd = false;
            if (eNext->coord == q->coord) skipEnd = true;
            for (int j = 0;j<open_list.size();j++) {
                if (open_list[j]->coord == eNext->coord && open_list[j]->f() <= eNext->f()) {
                    skipEnd = true;
                    break;
                }
            }
            if (!skipEnd) {
                for (int j = 0;j<closed_list.size();j++) {
                    if (closed_list[j]->coord == eNext->coord && closed_list[j]->f() <= eNext->f()) {
                        skipEnd = true;
                        break;
                    }
                }
            }
            if (!skipEnd) open_list.push_back(eNext);
        }
        closed_list.push_back(q);
        //cout << "CLOSED: " << closed_list.size() << " OPEN: " << open_list.size() << endl;
    }
    return NAV_NO_ROUTE;
}


//******************** Navigator functions ************************************

// These functions simply delegate to NavigatorImpl's functions.
// You probably don't want to change any of this code.

Navigator::Navigator()
{
    m_impl = new NavigatorImpl;
}

Navigator::~Navigator()
{
    delete m_impl;
}

bool Navigator::loadMapData(string mapFile)
{
    return m_impl->loadMapData(mapFile);
}

NavResult Navigator::navigate(string start, string end, vector<NavSegment>& directions) const
{
    return m_impl->navigate(start, end, directions);
}



//#include "provided.h"
//#include <string>
//#include <vector>
//#include <queue>
//#include "MyMap.h"
//#include <algorithm>
//
//using namespace std;
//
//class NavigatorImpl
//{
//public:
//    NavigatorImpl();
//    ~NavigatorImpl();
//    bool loadMapData(string mapFile);
//    NavResult navigate(string start, string end, vector<NavSegment>& directions) const;
//private:
//    MapLoader mapl;
//    SegmentMapper segMap;
//    AttractionMapper attMap;
//    string getDirection(GeoCoord pt1, GeoCoord pt2) const;
//    //void NavigatorImpl::funct(locale * q, vector<NavSegment> &directions) const;
//    
//    struct locale
//    {
//        GeoCoord gc;
//        locale *parent;
//        double g;
//        double h;
//        double f;
//        bool operator<(locale rhs)
//        {
//            return (f < rhs.f);
//            
//        }
//    };
//    
//};
//
//NavigatorImpl::NavigatorImpl()
//{
//}
//
//NavigatorImpl::~NavigatorImpl()
//{
//}
//
//bool NavigatorImpl::loadMapData(string mapFile)
//{
//    if (!mapl.load(mapFile))
//        return false;
//    segMap.init(mapl);
//    attMap.init(mapl);
//    return true;
//}
//
///*template <typename T>
// bool greaterF(T lhs, T rhs)
// {
//	//double lf = distanceEarthKM(startCoord, lhs) + distanceEarthKM(endCoord, lhs);
//	//double rf = distanceEarthKM(startCoord, rhs) + distanceEarthKM(endCoord, rhs);
//	return (lhs.f < rhs.f);
// }*/
//
//bool operator==(GeoCoord& left, GeoCoord& right)
//{
//    if (left.latitude == right.latitude && left.longitude == right.longitude)
//        return true;
//    return false;
//}
//
//bool operator==(GeoSegment lhs, GeoSegment rhs)
//{
//    if (lhs.start == rhs.start && lhs.end == rhs.end)
//        return true;
//    if (lhs.start == rhs.end && lhs.end == rhs.start)
//        return true;
//    return false;
//}
//
//
///*bool NavigatorImpl::navigate::operator<(locale lhs, locale rhs);
// {
//	return (lhs.f < rhs.f);
// }*/
//
//NavResult NavigatorImpl::navigate(string start, string end, vector<NavSegment> &directions) const
//{
//    GeoCoord startCoord, endCoord;
//    if (!attMap.getGeoCoord(start, startCoord))
//        return NAV_BAD_SOURCE;
//    if (!attMap.getGeoCoord(end, endCoord))
//        return NAV_BAD_DESTINATION;
//    directions.empty();
//    
//    //begin a*
//    //priority_queue<locale, decltype(greaterF<locale>)> closed;
//    //priority_queue<locale, decltype(greaterF<locale>)> open;
//    vector<locale*> closed;
//    vector<locale*> open;
//    
//    locale* first = new locale;
//    first->gc = startCoord;
//    first->parent = nullptr;
//    first->g = 0;
//    first->h = distanceEarthKM(startCoord, endCoord);
//    first->f = 0;
//    
//    open.push_back(first);
//    
//    //MyMap<GeoCoord, GeoCoord> cameFrom;
//    
//    //while there are still nodes in the open map
//    while (!open.empty())
//    {
//        cerr << "size " << open.size() << endl;
//        locale* q = open[0];
//        //generate q's successors
//        vector<StreetSegment> v = segMap.getSegments(q->gc);
//        for (int i = 0; i < v.size(); i++)
//        {
//            //check to see if we have reached the goal
//            if (v[i].segment.start == endCoord || v[i].segment.end == endCoord)
//            {
//                //success!!!
//                cerr << "success" << endl;
//                locale * p = q;
//                while (p != nullptr)
//                {
//                    cerr << p->gc.latitudeText << " " << p->gc.latitudeText << endl;
//                }
//                cerr << "that's all" << endl;
//                return NAV_SUCCESS; //this is a placeholder until you can return the correct array as well TODO
//            }
//            for (int j = 0; j < v[i].attractions.size(); j++)
//            {
//                if (v[i].attractions[j].geocoordinates == endCoord)
//                {
//                    cerr << "success2" << endl;
//                    locale * p = q;
//                    while (p != nullptr)
//                    {
//                        cerr << p->gc.latitudeText << " " << p->gc.latitudeText << endl;
//                        p = p->parent;
//                    }
//                    cerr << "that's all" << endl;
//                    return NAV_SUCCESS; //TODO See above placeholder
//                }
//            }
//            //update f for the coord.
//            locale* successor = new locale;
//            successor->gc = v[i].segment.end;
//            successor->parent = q;
//            successor->g = q->g + distanceEarthKM(q->gc, successor->gc);
//            successor->h = distanceEarthKM(successor->gc, endCoord);
//            successor->f = successor->g + successor->h;
//            
//            bool addThis = true;
//            for (int i = 0; i < open.size(); i++)
//            {
//                if (open[i]->gc == successor->gc && open[i]->f < successor->f)
//                {
//                    addThis = false;
//                    break;
//                }
//            }
//            for (int i = 0; i < closed.size(); i++)
//            {
//                if (closed[i]->gc == successor->gc && closed[i]->f < successor->f)
//                {
//                    addThis = false;
//                    break;
//                }
//            }
//            
//            if (addThis)
//            {
//                cerr << "add1 " << successor->gc.latitudeText << " " << successor->gc.latitudeText << endl;
//                open.push_back(successor);
//            }
//            else
//                cerr << "don't add1" << endl;
//            
//            //endCoord
//            locale * sEnd = new locale;
//            sEnd->gc = v[i].segment.start;
//            sEnd->parent = q;
//            sEnd->g = q->g + distanceEarthKM(q->gc, sEnd->gc);
//            sEnd->h = distanceEarthKM(sEnd->gc, endCoord);
//            sEnd->f = sEnd->g + sEnd->h;
//            
//            addThis = true;
//            //
//            for (int i = 0; i < open.size(); i++)
//            {
//                if (open[i]->gc == sEnd->gc && open[i]->f <= sEnd->f)
//                {
//                    addThis = false;
//                    break;
//                }
//            }
//            for (int i = 0; i < closed.size(); i++)
//            {
//                if (closed[i]->gc == sEnd->gc && closed[i]->f <= sEnd->f)
//                {
//                    addThis = false;
//                    break;
//                }
//            }
//            
//            if (addThis)
//            {
//                cerr << "add2 " << sEnd->gc.latitudeText << " " << sEnd->gc.latitudeText << endl;
//                open.push_back(sEnd);
//            }
//            else
//                cerr << "don't add2" << endl;
//        }
//        // remove q
//        closed.push_back(open[0]);
//        cerr << "deleting " << open.size() << endl;
//        open.erase(open.begin());
//        cerr << "deleted " << open.size() << endl;
//        cerr << "closed " << closed.size() << endl;
//        
//        // sort the vector
//        sort(open.begin(), open.end());
//    }
//    
//    return NAV_NO_ROUTE;
//    
//}
//
//
////this will be used to convert to the style that the nav uses
///*void NavigatorImpl::funct(locale * q, vector<NavSegment> &directions) const
// {
//	locale * p = q->parent;
//	locale * o = q;
//	while (p != nullptr) //TODO: literally no clue. should this be prepared to handle turns somehow?
//	{
// string name;
// vector<StreetSegment> possible = segMap.getSegments(o->gc);
// for (int k = 0; k < possible.size(); k++)
// {
// if (possible[k].segment == GeoSegment(o->gc, p->gc)) //accounts for both end =q, start = p and end =p, start= q
// name = possible[k].streetName;
// }
// directions.push_back(NavSegment(this->getDirection(p->gc, o->gc), name, distanceEarthKM(q->gc, p->gc), GeoSegment(p->gc, o->gc)));
// o = p;
// p = p->parent;
//	}
// }*/
//
//
//
//
//string NavigatorImpl::getDirection(GeoCoord pt1, GeoCoord pt2) const
//{
//    double degrees = angleOfLine(GeoSegment(pt1, pt2));
//    
//    if (degrees >= 0 && degrees <= 22.5)
//        return "east";
//    if (degrees > 22.5 && degrees <= 67.5)
//        return "northeast";
//    if (degrees > 67.5 && degrees <= 112.5)
//        return "north";
//    if (degrees > 112.5 && degrees <= 157.5)
//        return "northwest";
//    if (degrees > 157.5 && degrees <= 202.5)
//        return "west";
//    if (degrees > 202.5 && degrees <= 247.5)
//        return "southwest";
//    if (degrees > 247.5 && degrees <= 292.5)
//        return "south";
//    if (degrees > 292.5 && degrees <= 337.5)
//        return "southeast";
//    if (degrees > 337.5 && degrees < 360)
//        return "east";
//    return "east";
//}
//
//
//
////******************** Navigator functions ************************************
//
//// These functions simply delegate to NavigatorImpl's functions.
//// You probably don't want to change any of this code.
//
//Navigator::Navigator()
//{
//    m_impl = new NavigatorImpl;
//}
//
//Navigator::~Navigator()
//{
//    delete m_impl;
//}
//
//bool Navigator::loadMapData(string mapFile)
//{
//    return m_impl->loadMapData(mapFile);
//}
//
//NavResult Navigator::navigate(string start, string end, vector<NavSegment>& directions) const
//{
//    return m_impl->navigate(start, end, directions);
//}
